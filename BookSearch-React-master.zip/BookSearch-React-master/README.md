# BookSearch-React
A simple Book Search app using React JS and Google Books API

<img src="http://fethica.github.io/BookSearch-React/img/browser_books.jpg" alt="Book Search Preview" />

Demo : http://fethica.github.io/BookSearch-React/

##Credits :

- [Book Preview.](http://tympanus.net/codrops/2014/01/14/look-inside-book-preview-with-bookblock/)
- [React JS.](http://facebook.github.io/react/)
- [Google Books API](https://developers.google.com/books/?hl=en)
- [Twitter Bootstrap](http://getbootstrap.com)

Create by : [Fethi El Hassasna](https://twitter.com/fethica) © 2015
